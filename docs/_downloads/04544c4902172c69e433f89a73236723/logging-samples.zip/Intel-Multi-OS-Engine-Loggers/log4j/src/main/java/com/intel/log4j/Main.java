package com.intel.log4j;

import android.util.Log;

import com.intel.log4j.ui.AppViewController;

import de.mindpipe.android.logging.log4j.LogConfigurator;
import ios.NSObject;
import ios.foundation.NSArray;
import ios.foundation.NSDictionary;
import ios.foundation.NSFileManager;
import ios.foundation.NSURL;
import ios.foundation.enums.NSSearchPathDirectory;
import ios.foundation.enums.NSSearchPathDomainMask;
import ios.uikit.UIApplication;
import ios.uikit.UIWindow;
import ios.uikit.c.UIKit;
import ios.uikit.protocol.UIApplicationDelegate;

import com.intel.moe.natj.general.NatJ;
import com.intel.moe.natj.general.Pointer;
import com.intel.moe.natj.general.ann.Generated;
import com.intel.moe.natj.general.ann.RegisterOnStartup;
import com.intel.moe.natj.objc.ann.Selector;

import org.apache.log4j.Level;

import java.io.File;

@RegisterOnStartup
public class Main extends NSObject implements UIApplicationDelegate {

    public static void main(String[] args) {
        UIKit.UIApplicationMain(0, null, null, Main.class.getName());
    }

    @Selector("alloc")
    public static native Main alloc();

    protected Main(Pointer peer) {
        super(peer);
    }

    private UIWindow window;

    @Override
    @Selector("application:didFinishLaunchingWithOptions:")
    public boolean applicationDidFinishLaunchingWithOptions(UIApplication application, NSDictionary launchOptions) {
        initLogger();
        return true;
    }

    @Override
    @Selector("setWindow:")
    public void setWindow(UIWindow value) {
        window = value;
    }

    @Override
    @Selector("window")
    public UIWindow window() {
        return window;
    }

    private void initLogger() {

        //Create new LogConfigurator
        final LogConfigurator logConfigurator = new LogConfigurator();

        NSFileManager fileMgr = NSFileManager.defaultManager();
        NSArray ar = fileMgr.URLsForDirectoryInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask);
        String rootPath = ((NSURL) ar.firstObject()).fileSystemRepresentation();

        //Set log file dir and name
        logConfigurator.setFileName(rootPath + File.separator + "myapp.log");
        logConfigurator.setRootLevel(Level.ERROR);

        // Set log level of a specific logger
        logConfigurator.setLevel("org.apache", Level.ERROR);
        logConfigurator.configure();
    }
}
